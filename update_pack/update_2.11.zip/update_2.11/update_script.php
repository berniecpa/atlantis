<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();


$meta_pixel = array(
    'meta_pixel' => array(
        'type' => 'VARCHAR',
        'constraint' => '255',
        'default' => null,
        'null' => TRUE,
        'collation' => 'utf8_unicode_ci'
    )
);

$CI->dbforge->add_column('user', $meta_pixel);

$count = $CI->db->get_where("settings", array("type" => "meta_pixel"))->num_rows();

if ($count == 0) {

    $data['type'] = "meta_pixel";
    $data['description'] = "0";
    $CI->db->insert('settings', $data);
}



//update data in settings table
$settings_datas['description'] = '2.11';
$CI->db->where('type', 'version');
$CI->db->update('settings', $settings_datas);
